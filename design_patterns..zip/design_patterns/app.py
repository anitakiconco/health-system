import os
from flask import Flask, app, render_template, request, url_for, redirect
from flask_sqlalchemy import SQLAlchemy


#from app import db




from sqlalchemy.sql import func

basedir = os.path.abspath(os.path.dirname(__file__))
from flask import Flask
from models import db

def create_app():
 app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI']=\
     'sqlite:///' + os.path.join(basedir, 'database.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
