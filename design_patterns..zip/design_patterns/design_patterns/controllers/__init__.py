# web controllers
from design_patterns.controllers.web.authentication import *
from design_patterns.controllers.web.reports import *

# api controllers
from design_patterns.controllers.api.authentication import *
from design_patterns.controllers.api.police import *
