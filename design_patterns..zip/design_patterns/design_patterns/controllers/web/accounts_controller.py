# This class represents a Factory Method pattern, which encapsulates the creation of `Account` instances.
# It provides a static method `create_account` to create instances of `Account`.
# The factory method abstracts the creation process, allowing for flexibility in creating `Account` objects.

from design_patterns.models import Account


class AccountFactory:
    @staticmethod
    def create_account(patient_id, amount, payment_reason):
        return Account(patient_id=patient_id, amount=amount, payment_reason=payment_reason)


# This metaclass represents a Singleton pattern, ensuring that only one instance of a class exists throughout the
# application's lifecycle. It maintains a dictionary of instances created and returns the existing instance if it
# already exists. If not, it creates a new instance and adds it to the dictionary.

class SingletonMeta(type):
    _instances = {}

    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super().__call__(*args, **kwargs)
        return cls._instances[cls]


# This class represents a Singleton pattern, ensuring that only one instance of `AccountManager` exists.
# It manages the creation of `Account` instances using the `AccountFactory`.
# By making `AccountManager` a singleton, we ensure that there is only one instance responsible for creating accounts.
# This ensures that the creation logic is centralized and consistent throughout the application.

class Singleton(metaclass=SingletonMeta):
    pass


class AccountManager(Singleton):
    def __init__(self):
        # Initialize the AccountFactory instance.
        self.account_factory = AccountFactory()

    # This method delegates the creation of `Account` instances to the `AccountFactory`.
    # It abstracts the creation process from the client code.
    # Clients can create `Account` instances without knowing the details of how they are created.
    def create_account(self, patient_id, amount, payment_reason):
        return self.account_factory.create_account(patient_id, amount, payment_reason)
