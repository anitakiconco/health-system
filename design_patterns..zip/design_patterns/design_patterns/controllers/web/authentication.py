from flask import render_template, url_for, redirect, flash
from design_patterns import app, bcrypt
from design_patterns.forms.authentication import LoginForm
from flask_login import current_user, logout_user, login_user

from design_patterns.models import User


@app.route('/', methods=['GET', 'POST'])
@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    else:
        form = LoginForm()
        login_page = 'frontend/authentication/login.html'
        if form.validate_on_submit():
            existing_user = User.query.filter_by(username=form.username.data).first()
            if existing_user and bcrypt.check_password_hash(existing_user.password, form.password.data):
                login_user(existing_user, remember=form.remember.data)
                return redirect(url_for('dashboard'))
            else:
                flash('Login Unsuccessful. Please check username and password', 'danger')
        return render_template(login_page, form=form)


@app.route('/register')
def register():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    else:
        register_page = 'frontend/authentication/register.html'
        return render_template(register_page)


@app.route('/forgot_password')
def forgot_password():
    return "forgot password"


@app.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('login'))
