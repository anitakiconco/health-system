import uuid

from design_patterns import db
from design_patterns.models import Message


# Adapter Pattern: Converting Message class to support different databases
class MessageAdapter:
    def __init__(self, message):
        self.message = message

    def save_message(self, sent_from, received_by, message):
        # Saving message in the adapted format
        new_message = self.message(sent_from=sent_from, received_by=received_by, message=message)
        db.session.add(new_message)
        db.session.commit()


# Decorator Pattern: Adding extra functionality to the Message class
class EncryptedMessage(Message):
    def __init__(self, sent_from, received_by, message, encryption_key):
        super().__init__(sent_from=sent_from, received_by=received_by, message=message)
        self.encryption_key = encryption_key

    def save_message(self):
        # Encrypt the message before saving
        encrypted_message = self.encrypt_message(self.message, self.encryption_key)
        super().save_message(sent_from=self.sent_from, received_by=self.received_by, message=encrypted_message)

    def encrypt_message(self, message, encryption_key):
        # Implement encryption logic here
        # For demonstration, simply return the original message
        return message
