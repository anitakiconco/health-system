import uuid

from design_patterns import db
from sqlalchemy import DateTime, func, ForeignKey
from sqlalchemy.orm import relationship


# Observer Pattern: Define an Observer interface
class PatientObserver:
    def update(self, patient):
        pass


# Concrete Observer: Define a concrete observer class
class PatientLogObserver(PatientObserver):
    def update(self, patient):
        # Log patient information
        print(f"Patient with ID {patient.id} updated.")


# Strategy Pattern: Define a strategy interface
class PatientStorageStrategy:
    def store_patient(self, patient):
        pass


# Concrete Strategy: Define a concrete strategy class
class DatabasePatientStorageStrategy(PatientStorageStrategy):
    def store_patient(self, patient):
        # Store patient information in the database
        db.session.add(patient)
        db.session.commit()


class Patient(db.Model):
    __tablename__ = 'patients'

    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True, nullable=False)
    contact_id = db.Column(db.String(36), ForeignKey('contacts.id'), nullable=True)
    admission_date = db.Column(DateTime, nullable=True)
    discharge_date = db.Column(DateTime, nullable=True)
    signs_and_symptoms = db.Column(db.Text, nullable=True)
    disease = db.Column(db.String(36), nullable=True)

    contact = relationship('Contact', backref='patient_contact')

    # Context class: Patient class acts as a context class
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.observers = []
        self.storage_strategy = DatabasePatientStorageStrategy()  # Set the default storage strategy

    # Attach an observer to the patient
    def attach(self, observer):
        self.observers.append(observer)

    # Detach an observer from the patient
    def detach(self, observer):
        self.observers.remove(observer)

    # Notify all observers about the patient update
    def notify_observers(self):
        for observer in self.observers:
            observer.update(self)

    # Set storage strategy for patient storage
    def set_storage_strategy(self, storage_strategy):
        self.storage_strategy = storage_strategy

    # Save patient using the selected storage strategy
    def save(self):
        self.storage_strategy.store_patient(self)
        self.notify_observers()
