from design_patterns import app
from flask import render_template, request, url_for, redirect
from flask_login import current_user, login_required

from design_patterns.forms import UsersForm
from design_patterns.helpers.document_upload_helpers import save_document
from design_patterns.helpers.general_helpers import user_type_mapping
from design_patterns.models import UserType
from design_patterns.serializers.users_serializer import get_users, create_user, get_statistics


@app.route('/dashboard')
@login_required
def dashboard():
    dashboard_page = 'backend/administrator/dashboard.html'
    return render_template(dashboard_page, title='Dashboard', statistics=get_statistics())


@app.route('/all_users', methods=['POST', 'GET'])
@login_required
def users():
    form = UsersForm()
    all_users = get_users()
    if request.method == 'POST':
        user_type = UserType.ADMIN if form.user_type.data == 'admin' else UserType.USER
        create_user(form.name.data, form.username.data, form.email.data,
                    save_document(form.photo.data, 'profile_pictures'), user_type, form.password.data, )
        return redirect(url_for('users'))
    users_page = 'backend/administrator/users/users.html'

    return render_template(users_page, title='All Users', form=form, modal_title='Create User', users=all_users,
                           user_type_mapping=user_type_mapping)
