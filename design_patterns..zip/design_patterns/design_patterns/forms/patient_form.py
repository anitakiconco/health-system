from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, DateField, TextAreaField
from wtforms.validators import DataRequired, Optional


class PatientsForm(FlaskForm):
    name = StringField('Name', validators=[DataRequired()])
    location = StringField('Location', validators=[DataRequired()])
    phone_number = StringField('Phone Number', validators=[DataRequired()])
    admission_date = DateField('Admission Date', format='%Y-%m-%d', validators=[DataRequired()])
    discharge_date = DateField('Discharge Date', format='%Y-%m-%d', validators=[Optional()])
    signs_and_symptoms = TextAreaField('Signs And Symptoms', validators=[DataRequired()])
    disease = StringField('Disease', validators=[Optional()])
    submit = SubmitField('Submit')
