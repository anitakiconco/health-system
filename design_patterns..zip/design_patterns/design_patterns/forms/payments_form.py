from flask_wtf import FlaskForm
from wtforms import SubmitField, SelectField, FloatField
from wtforms.validators import DataRequired

from design_patterns.models import Patient, Account


class PaymentsForm(FlaskForm):
    patient = SelectField('Patient Names', validators=[DataRequired()])
    amount = FloatField('Amount', validators=[DataRequired()])
    payment_reason = SelectField('Payment For', validators=[DataRequired()])
    submit = SubmitField('Submit')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.populate_choices()

    def populate_choices(self):
        patients = Patient.query.all()
        self.patient.choices = [(str(patient.id), patient.name) for patient in patients]

        accounts = Account.query.all()
        self.payment_reason.choices = [(str(account.id), account.payment_reason) for account in accounts]
