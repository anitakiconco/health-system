from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, EmailField, FileField, SelectField, PasswordField
from wtforms.validators import DataRequired, EqualTo
from design_patterns.models import UserType


class UsersForm(FlaskForm):
    name = StringField('Name', validators=[DataRequired()])
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    email = EmailField('Email', validators=[DataRequired()])
    photo = FileField('User Photo', validators=[DataRequired()])
    user_type = SelectField('User Type', validators=[DataRequired()])
    submit = SubmitField('Submit')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.populate_choices()

    def populate_choices(self):
        user_types = [(user_type.value, user_type.name.title().replace('_', ' ')) for user_type in UserType]
        self.user_type.choices = user_types
