import secrets
import os
from PIL import Image
from design_patterns import app


def save_document(document, folder_name):
    random_hex = secrets.token_hex(8)
    _, f_ext = os.path.splitext(document.filename)
    document_file_name = random_hex + f_ext
    document_path = os.path.join(app.root_path, 'static/img/' + folder_name, document_file_name)

    if is_image(document.filename):
        output_size = (125, 125)
        i = Image.open(document)
        i.thumbnail(output_size)
        i.save(document_path)
    else:
        document.save(document_path)

    return document_file_name


def is_image(filename):
    image_extensions = {".jpg", ".jpeg", ".png", ".gif"}
    return any(filename.lower().endswith(ext) for ext in image_extensions)

