from design_patterns.models import UserType

user_type_mapping = {
    UserType.ADMIN: 'Administrator',
    UserType.USER: 'User',
}
