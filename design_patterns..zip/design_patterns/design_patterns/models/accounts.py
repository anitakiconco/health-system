import uuid
from enum import Enum

from design_patterns import db
from sqlalchemy import Enum as EnumType, Float, ForeignKey
from sqlalchemy.orm import relationship


class PaymentReason(Enum):
    MEDICAL = 'Medical expenses'
    PRESCRIPTION = 'Prescription costs'
    LAB_TEST = 'Laboratory testing'
    OTHER = 'Other reasons'


class Account(db.Model):
    __tablename__ = 'accounts'

    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True, nullable=False)
    patient_id = db.Column(db.String(36), ForeignKey('patients.id'), nullable=True)
    amount = db.Column(Float)
    payment_reason = db.Column(EnumType(PaymentReason), default=PaymentReason.OTHER)
