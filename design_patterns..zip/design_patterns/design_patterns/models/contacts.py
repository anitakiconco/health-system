import uuid
from design_patterns import db


class Contact(db.Model):
    __tablename__ = 'contacts'

    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True, nullable=False)
    location = db.Column(db.String(150), nullable=False)
    phone_number = db.Column(db.String(150), nullable=False)
