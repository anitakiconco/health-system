import uuid

from design_patterns import db
from sqlalchemy import DateTime, text, func, ForeignKey
from sqlalchemy.orm import relationship


class Message(db.Model):
    __tablename__ = 'messages'

    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True, nullable=False)
    sent_from = db.Column(db.String(36), ForeignKey('users.id'), nullable=True)
    received_by = db.Column(db.String(36), ForeignKey('users.id'), nullable=True)
    message = db.Column(db.Text)
    message_sender = relationship('User', backref='message_sender')
    message_receiver = relationship('User', backref='message_receiver')
