import uuid

from design_patterns import db
from sqlalchemy import DateTime, func, ForeignKey
from sqlalchemy.orm import relationship


class Patient(db.Model):
    __tablename__ = 'patients'

    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True, nullable=False)
    contact_id = db.Column(db.String(36), ForeignKey('contacts.id'), nullable=True)
    admission_date = db.Column(DateTime, nullable=True)
    discharge_date = db.Column(DateTime, nullable=True)
    signs_and_symptoms = db.Column(db.Text, nullable=True)
    disease = db.Column(db.String(36), nullable=True)

    contact = relationship('Contact', backref='patient_contact')
