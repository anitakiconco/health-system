import uuid
from design_patterns import db, login_manager
from sqlalchemy import DateTime, text, func, Enum
import enum
from flask_login import UserMixin


class UserType(enum.Enum):
    HEALTHCARE_PROVIDER = 'staff'
    ADMINISTRATOR = 'admin'
    FINANCE = 'finance'


class User(UserMixin, db.Model):
    __tablename__ = 'users'

    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True, nullable=False)
    name = db.Column(db.String(100), nullable=False)
    username = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=True)
    password = db.Column(db.String(150), nullable=False)
    photo = db.Column(db.String(100), nullable=False)
    user_type = db.Column(Enum(UserType), default=UserType.HEALTHCARE_PROVIDER, nullable=False)
    created_at = db.Column(DateTime, server_default=func.now(), nullable=False)
    updated_at = db.Column(DateTime, server_default=func.now(), nullable=False)
