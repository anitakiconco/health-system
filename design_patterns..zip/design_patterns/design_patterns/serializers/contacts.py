from design_patterns import db
from design_patterns.models import Contact


def create_contact(position_or_location, phone_number, email, photo_path):
    try:
        contact = Contact.query.filter_by(phone_number=phone_number).first()
        e_email = Contact.query.filter_by(email=email).first()
        if contact and e_email:
            return contact

        contact = Contact(position_or_location=position_or_location, phone_number=phone_number, email=email,
                          photo_path=photo_path)

        db.session.add(contact)
        db.session.commit()

        return contact
    except Exception as e:
        # Handle the exception, you can log it or return an error response
        db.session.rollback()  # Rollback changes in case of an error
        return None
