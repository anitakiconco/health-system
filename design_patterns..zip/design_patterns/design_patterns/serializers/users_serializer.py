from design_patterns import db, bcrypt
from design_patterns.models import User


def create_user(name, username, email, photo, user_type, password):
    user = User(name=name, username=username, email=email, photo=photo, user_type=user_type,
                password=bcrypt.generate_password_hash(password).decode('utf-8'))
    db.session.add(user)
    db.session.commit()
    return user


def get_users():
    return User.query.all()


def get_user_by_type(user_type):
    return User.query.filter_by(user_type=user_type).get()


def get_statistics():
    users_count = User.query.count()
    return {
        'users_count': users_count,
    }


def delete_user(user_id):
    user_to_delete = User.query.filter_by(id=user_id).first()
    if user_to_delete:
        db.session.delete(user_to_delete)
        db.session.commit()
        return True
    return False
