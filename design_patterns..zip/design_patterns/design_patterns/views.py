# views.py
from flask import Blueprint
from models import User

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def index():
    users = User.query.all()
    return 'Hello, {} users!'.format(len(users))
