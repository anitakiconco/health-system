import os
from flask import Flask, render_template, request, url_for, redirect
from flask_sqlalchemy import SQLAlchemy
import uuid
from sqlalchemy import ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy import Enum as EnumType, Float
from sqlalchemy import DateTime
from flask_login import UserMixin

from enum import Enum
from sqlalchemy import Enum as EnumSQL

from app import db

db = SQLAlchemy()


from sqlalchemy.sql import func



class UserType(Enum):
     HEALTHCARE_PROVIDER = 'staff'
ADMINISTRATOR = 'admin'
FINANCE = 'finance'
    
    
   
   

class Patient(db.Model):
    __tablename__ = 'patients'

    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True, nullable=False)
    contact_id = db.Column(db.String(36), ForeignKey('contacts.id'), nullable=True)
    admission_date = db.Column(DateTime, nullable=True)
    discharge_date = db.Column(DateTime, nullable=True)
    signs_and_symptoms = db.Column(db.Text, nullable=True)
    disease = db.Column(db.String(36), nullable=True)

    contact = relationship('Contact', backref='patient_contact')
    
    
    
    class User(UserMixin, db.Model):
     __tablename__ = 'users'

    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True, nullable=False)
    name = db.Column(db.String(100), nullable=False)
    username = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=True)
    password = db.Column(db.String(150), nullable=False)
    photo = db.Column(db.String(100), nullable=False)
    user_type = db.Column(Enum(UserType), default=UserType.HEALTHCARE_PROVIDER, nullable=False)
    created_at = db.Column(DateTime, server_default=func.now(), nullable=False)
    updated_at = db.Column(DateTime, server_default=func.now(), nullable=False)
    
    
    class Message(db.Model):
     __tablename__ = 'messages'

    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True, nullable=False)
    sent_from = db.Column(db.String(36), ForeignKey('users.id'), nullable=True)
    received_by = db.Column(db.String(36), ForeignKey('users.id'), nullable=True)
    message = db.Column(db.Text)
    message_sender = relationship('User', backref='message_sender')
    message_receiver = relationship('User', backref='message_receiver')

class PaymentReason(Enum):
      MEDICAL = 'Medical expenses'
PRESCRIPTION = 'Prescription costs'
LAB_TEST = 'Laboratory testing'
OTHER = 'Other reasons'

class Account(db.Model):
    __tablename__ = 'accounts'

    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True, nullable=False)
    patient_id = db.Column(db.String(36), ForeignKey('patients.id'), nullable=True)
    amount = db.Column(Float)
    payment_reason = db.Column(EnumType(PaymentReason), default=PaymentReason.OTHER)
    
    
    
    class Contact(db.Model):
     __tablename__ = 'contacts'

    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True, nullable=False)
    location = db.Column(db.String(150), nullable=False)
    phone_number = db.Column(db.String(150), nullable=False)
    
    



